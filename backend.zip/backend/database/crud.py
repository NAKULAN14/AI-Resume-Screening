from sqlalchemy.orm import Session
from database.models import Candidate
def create_candidate(db: Session, candidate_data):
    existing_candidate = (
        db.query(Candidate)
        .filter(Candidate.email == candidate_data["email"])
        .first()
    )
    if existing_candidate:
        return existing_candidate
    candidate = Candidate(
        name=candidate_data["name"],
        email=candidate_data["email"],
        phone=candidate_data["phone"],
        skills=candidate_data["skills"],
        score=candidate_data["score"],
        resume_path=candidate_data["resume_path"]
    )
    db.add(candidate)
    db.commit()
    db.refresh(candidate)
    return candidate