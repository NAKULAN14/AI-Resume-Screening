from fastapi import APIRouter, UploadFile, File, HTTPException
from typing import List
from services.pdf_reader import extract_text
from services.parser import parse_resume
from services.ranking_service import rank_candidates
from services.jd_parser import parse_job_description
router = APIRouter()


@router.post("/rank")
async def rank_resumes(
    job_description: UploadFile = File(...),
    resumes: list[UploadFile] = File(...)
):  

    if job_description.content_type != "application/pdf":
        raise HTTPException(
            status_code=400,
            detail="Job Description must be a PDF."
        )

    if len(resumes) == 0:
        raise HTTPException(
            status_code=400,
            detail="Please upload at least one resume."
        )

    for resume in resumes:

        if resume.content_type != "application/pdf":
            raise HTTPException(
                status_code=400,
                detail=f"{resume.filename} is not a PDF."
            )

    job_description_text = extract_text(job_description.file)

    parsed_resumes = []
    for resume in resumes:

        resume_text = extract_text(resume.file)
        candidate = parse_resume(resume_text)
        candidate["text"] = resume_text
        candidate["resume_path"] = resume.filename

        parsed_resumes.append(candidate)
    job_description_text = extract_text(job_description.file)
    parsed_jd = parse_job_description(job_description_text)
    ranked_candidates = rank_candidates(
        job_description_text,
        parsed_resumes
    )
    return {
        "total_candidates": len(ranked_candidates),
        "rankings": ranked_candidates
    }